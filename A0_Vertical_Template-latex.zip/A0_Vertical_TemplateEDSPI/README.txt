How to use the template:

- Change the headline and change the lab logo: 
    Go to beamerthemeI6pd2.sty file and change the block inside \setbeamertemplate{headline}.

- Any text content (title, author, affiliation, footer, text block) can be changed in poster.tex.